/* Computer programming 2, COSC 1437-58003 Clara Howard
   Dr_T
   football scoreboard
*/

#include <iostream> 
#include <string>
#include <unistd.h>
using namespace std;

class Team 
{
  private:
    int score;
    bool homeStatus;
    string name;
    int shotsOnTouchdown;
  public:
      Team() //default constructor
      {
        score = 0;
        homeStatus = false; //visitor = false, home = true;
        name = "Oklahoma Sooners";
        shotsOnTouchdown = 0;
      }
      void setScore(int s) { score = s; }
      void setHomeStatus(bool hs) { homeStatus = hs; }
      void setName(string n) { name = n; }
      void setShotsOnTouchdown(int sotd) { shotsOnTouchdown = sotd; }
      int getScore() const { return score; }
      bool getHomeStatus() const { return homeStatus; }
      string getName() const { return name; }
      int getShotsOnTouchdown() const { return shotsOnTouchdown; }
};

class Scoreboard
{
  private:
    int half;
    Team home; //object that is a member of another object
    Team visitor;
  public:
    Scoreboard()
    {
      half = 0;
    }
    void setHalf(int h) { half = h; }
    void setHome(Team hSet) { home = hSet; }
    void setVisitor(Team vSet) { visitor = vSet; }
    int getHalf() const { return half; }
    Team getHome() const { return home; }
    Team getVisitor() const { return visitor; }
    void showScoreboard()
    {
      string color = "";
      string reset = "\x1b[0m";
      color = "\x1b[34;4m"; //blue
      string score = "\x1b[96;1m"; //score color
      cout << color << "American football scoreboard" << reset << endl;
      cout << home.getName() << "\t\t" << visitor.getName() << endl;
      cout << score << home.getScore() << reset << "\t\t" << visitor.getScore() << endl;
    }
};

int main()
{
  Scoreboard s;
  Team tOne;
  Team tTwo;
  string newName = "";
  string userChoice = "";
  int newScore = 0;

  //set the home Team
  tOne.setHomeStatus(true); //tOne is now the home team

  //add some inital data to s
  s.setHome(tOne);
  s.setVisitor(tTwo);

  //now loop to make an interactive menu

  do
  {
      system("clear"); //clear the screen of previous information
      s.showScoreboard(); //show the curent scoreboard data
      //menu choices
      cout << "A = Update Home Team name" << endl;
      cout << "B = Update Home Team score" << endl;
      cout << "E = Exit" << endl;
      cout << ">";
      cin >> userChoice;

      if(userChoice == "A" || userChoice == "a")
      {
        cout << "****Update Home Team score module*** " << endl;
        cout << "\nPlease enter a new name for the home team: ";
        cin >> newName;
        tOne.setName(newName);
      }
      else if(userChoice == "B" || userChoice == "b")
      {
        cout << "\nUpdate Home Score Module****" << endl;
        cout << "\nPlease enter a new score for the home team: ";
        cin >> newScore;
        tOne.setScore(newScore);
      }
      else if(userChoice == "E" || userChoice == "e")
      {
        cout << "Exit chosen." << endl;
      }
      else
      {
        cout << "\nInvalid input." << endl;
        sleep(2);
      }

      s.setHome(tOne); //refreshes the data in score

  }while(userChoice != "E" && userChoice != "e");

  return 0;
}