//Student Name: Clara Howard

//Teacher: Dr. Tyson McMillan

//Date: 11-7-2020

//A program to practice working with multi-dimensional arrays

#include <iostream>
#include <iomanip>

using namespace std;

/*

Research Input data: go to http://www.weather.com

Pick two cities of your choice. Fill in the temperature for the 7 days of this week of both cities. Fill in this text data table, which will be used in your program.

//Fort_Worth = 1, Frisco = 2  Replace City_One and City_Two with the names of your cities

//Data Table

//City X, Day X: Temp

Fort_Worth, Day 1: 79 F

Fort_Worth, Day 2: 79 F

Fort_Worth, Day 3: 74 F

Fort_Worth, Day 4: 72 F

Fort_Worth, Day 5: 76 F

Fort_Worth, Day 6: 76 F

Fort_Worth, Day 7: 77 F

Frisco, Day 1: 78 F

Frisco, Day 2: 77 F

Frisco, Day 3: 70 F

Frisco, Day 4: 70 F

Frisco, Day 5: 73 F

Frisco, Day 6: 73 F

Frisco, Day 7: 74 F

*/


int main()

{

      const int CITY = 2;

      const int WEEK = 7;

 

    int temperature[CITY][WEEK];

    //Note your input data from the above

    cout << "Enter all temperature for a week of Fort Worth and then Frisco. \n";

 

    // Inserting the values into the temperature array

    //note for every dimension of the array you need a for loop 2 dimensions = 2 for loops

    for (int i = 0; i < CITY; ++i)

    {

        for(int j = 0; j < WEEK; ++j)

        {

            cout << "Fort Worth " << i + 1 << ", Day " << j + 1 << " : ";

            cin >> temperature[i][j];

        }

        cout << endl;

    }

 

    cout << "\n\nDisplaying Values:\n";

 

    // Accessing the values from the temperature array

    for (int i = 0; i < CITY; ++i)

    {

        for(int j = 0; j < WEEK; ++j)

        {

            cout << "Frisco " << i + 1 << ", Day " << j + 1 << " = " << temperature[i][j] << endl;

        }
      
      cout << endl;
      
    }

  return 0;
